
package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Conversacion;

/**
 *
 * @author LidiaVillarreal
 */
public class Model {
    
    private ArrayList <Conversacion> conversaciones;
    private IRepository repository;
    File ficheroEstadoSerializado;
    private final IRepository respository;
    
    public Model (IRepository respository, ILLM llm){
        this.respository = repository;
        ficheroEstadoSerializado=Paths.get (System.getProperty ("user.home"), "Desktop", "jLLM2", "jLLM.bin").toFile ();
        conversaciones=new ArrayList <> ();
    }

    

 
    
    public void agregarConversacion (String id){
        Conversacion conversacion = new Conversacion (id);
        conversaciones.add (conversacion);
    }
    
    public boolean cargarEstadoAplicacion (){
        if (ficheroEstadoSerializado.exists() && ficheroEstadoSerializado.isFile()) {
                ObjectInputStream ois = null;
                try {
                    //notifica al usuario cuantas conversaciones se han cargado con un mensaje
                    ois = new ObjectInputStream(new FileInputStream(ficheroEstadoSerializado));
                    try {
                        this.conversaciones = (ArrayList<Conversacion>) ois.readObject();
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } catch (IOException ex) {
                    // Dejamos el error para la depuración, por el canal err.
                    System.err.println("Error durante la deserialización: " + ex.getMessage());
                    return false;
                } finally {
                    if (ois != null) {
                        try {
                            ois.close();
                        } catch (IOException ex) {
                            // Dejamos el error para la depuración, por el canal err.
                            System.err.println("Error durante la deserialización: " + ex.getMessage());
                            return false;
                        }
                    }
                }
                return true;
            } else {
                System.out.println ("No existe el fichero, parece que es la primera ejecución del programa");
                return false;
            }

        }
    
     public boolean guardarEstadoAplicacion() {

        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(ficheroEstadoSerializado));
            //oos.writeObject(conversaciones);
            return true;
        } catch (IOException ex) {
            // Dejamos el error para la depuración, por el canal err.
            System.err.println("Error durante la serialización: " + ex.getMessage());
            return false;
        } finally {
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException ex) {
                    // Dejamos el error para la depuración, por el canal err.
                    System.err.println("Error al cerrar el flujo: " + ex.getMessage());
                    return false;
                }
            }
        }

    }

    public boolean gestionarConversacion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean exportarConversaciones() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean importarConversaciones() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean cargarEstadoAplicación() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void iniciarConversacion(Conversacion conversacion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     
    
    
}
