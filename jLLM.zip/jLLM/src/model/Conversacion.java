
package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LidiaVillarreal
 */

/*
APARENTEMENTE HECHO
*/

public class Conversacion {
    // Atributos
    private String id; //Nombre LLM
    private List<String> mensajes;
    private long fechaInicio;
    private long fechaFin;

    // Constructor
    public Conversacion(String id) {
        this.id = id;
        this.mensajes = new ArrayList<>();
        this.fechaInicio = System.currentTimeMillis() / 1000; // Fecha de inicio en segundos
        this.fechaFin = -1; // Fecha de fin inicializada a -1, indicando que la conversación está activa
    }

    Conversacion(Conversacion conversacion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<String> getMensajes() {
        return mensajes;
    }

    public void setMensajes(List<String> mensajes) {
        this.mensajes = mensajes;
    }

    public long getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(long fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public long getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(long fechaFin) {
        this.fechaFin = fechaFin;
    }
    
}
