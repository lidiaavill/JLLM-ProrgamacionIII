
package model;



/**
 *
 * @author LidiaVillarreal
 */


/*
CREO QUE ESTARÍA COMPLETADO
*/
public class Frase {
    
    //Para RandomCVSLLM
    
    private String tipo;
    private String longitud;
    private String oracion;

    public Frase(String tipo, String longitud, String oracion) {
        this.tipo = tipo;
        this.longitud = longitud;
        this.oracion = oracion;
    }
    
    public static Frase getFraseFromDelimitedString (String delimitedString, String delimiter){
      // Con split es posible separar por el delimitador
        String[] chunks = delimitedString.split(delimiter);
        
        if(chunks.length != 3){
            // Esto proximamente será una excepción
            // Tomamos linea como inválida
            return null;
        }
        
        try{
            String tipo = chunks[0];
            String longitud= chunks[1];
            String oracion = chunks[2];
            Frase f = new Frase(tipo,longitud,oracion);
            return f;
        }
        catch(Exception e){
            // Tomamos linea como inválida
            return null;
        }
    }  
    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getLongitud() {
        return longitud;
    }

    public void setLongitud(String longitud) {
        this.longitud = longitud;
    }

    public String getOracion() {
        return oracion;
    }

    public void setOracion(String oracion) {
        this.oracion = oracion;
    }    
    
}
