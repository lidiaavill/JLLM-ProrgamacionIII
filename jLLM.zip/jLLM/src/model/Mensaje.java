
package model;

import java.time.Instant;

/**
 *
 * @author LidiaVillarreal
 */

/*
APARENTEMENTE COMPLETADO
*/


public class Mensaje {
    // Atributos
    private String emisor;
    private long fecha;
    private String contenido;

    // Constructor
    public Mensaje(String emisor, String contenido) {
        this.emisor = emisor;
        this.fecha = Instant.now().getEpochSecond();
        this.contenido = contenido;
    }

    public String getEmisor() {
        return emisor;
    }

    public void setEmisor(String emisor) {
        this.emisor = emisor;
    }

    public long getFecha() {
        return fecha;
    }

    public void setFecha(long fecha) {
        this.fecha = fecha;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
    
    
}
