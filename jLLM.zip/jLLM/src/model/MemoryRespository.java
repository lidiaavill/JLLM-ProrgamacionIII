
package model;

import java.util.ArrayList;


/**
 *
 * @author LidiaVillarreal
 */


/*
MIRAR PORQUE HABRÁ MUCHAS COSAS MAL
*/


public class MemoryRespository implements IRepository {

    ArrayList <Conversacion> conversaciones;
        
    public MemoryRespository( ) {
         
        conversaciones = new ArrayList <> ();
        //Fake repository
    }    
            
     
    @Override
    public ArrayList<Conversacion> importarConversaciones() {
        return conversaciones;
    }

    @Override
    public boolean exportarConversaciones(ArrayList<Conversacion> conversaciones) {
         // Si queremos matener esto en memoria como otro objeto
        // deberemos hacer una copia
        this.conversaciones.clear ();
        for (Conversacion conversacion : conversaciones){
            this.conversaciones.add (new Conversacion (conversacion));
        }
       // De otro modo se borraría aquí también ya que apuntan al mismo objeto.
       
       return true;
    }
    
}
