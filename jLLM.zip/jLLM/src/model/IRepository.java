
package model;
import java.util.ArrayList;


/**
 *
 * @author LidiaVillarreal
 */
public interface IRepository {
    
    public ArrayList <Conversacion> importarConversaciones ();
    
    public boolean exportarConversaciones (ArrayList <Conversacion> conversaciones);
    
}
