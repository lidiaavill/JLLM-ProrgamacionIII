
package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import model.Conversacion;
import model.Mensaje;



/*APARENTEMENTE CLASE ACABADA
¿DUDA?
SE PUEDE PONER VARIABLE AHÍ FUERA STRING ID?? PARA EL RETURN ESE
FALTARÍA INCLUIR MAS CLASES
*/

/**
 *
 * @author LidiaVillarreal
 */
public class FakeILLM implements ILLM {
        
    private String id;

    @Override
    public String speak (String mensaje){
        
        //Respuesta predefinida
        String respuesta="No entiendo tu mensaje";
        
        if (mensaje.toLowerCase().contains ("hola")){
            respuesta = "¡Hola! ¿En que puedo ayudarte?";
        }else if (mensaje.toLowerCase().contains ("como estas")){
            respuesta = "Bien, gracias por preguntar";
        }else if (mensaje.toLowerCase().contains ("gracias")){
            respuesta = "De nada, ¿te puedo ayudar en algo mas?";
        }
        return respuesta;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String getId() {
        return id;
    }
    
}
