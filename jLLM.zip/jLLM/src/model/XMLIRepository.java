
package model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.ArrayList;

/**
 *
 * @author LidiaVillarreal
 */


/*
APARENTEMENTE ESTÁ COMPLETO
*/


public class XMLIRepository implements IRepository {

    @Override
    public ArrayList<Conversacion> importarConversaciones() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public boolean exportarConversaciones(ArrayList<Conversacion> conversaciones) {
       Path ruta = Paths.get (System.getProperty ("user.home"), "Desktop", "jLLM2", "jLLMXML.xml");
       File f = ruta.toFile ();
       
       if (!exportarListaDeConversacionesAXML(conversaciones, f)) {
            System.out.println("Hubo un problema con la exportación");
            return false;
        }else{
            System.out.println("Exportado con éxito");
            System.out.println("Vea el resultado en:"+f.getAbsolutePath());
            return true;
        }
    }
    
    public static boolean exportarListaDeConversacionesAXML(ArrayList<Conversacion> conversaciones, File f) {
        try {
            XmlMapper xmlMapper = new XmlMapper();
            String xml = xmlMapper.writeValueAsString(conversaciones);
            Files.write(f.toPath(), xml.getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (JsonProcessingException ex) {
            
            System.err.println("Error:" + ex.getMessage());
            return false;
        } catch (IOException ex) {
            System.err.println("Error:" + ex.getMessage());
            return false;
        }
    }
    
    
}
