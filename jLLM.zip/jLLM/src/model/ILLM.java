
package model;

/**
 *
 * @author LidiaVillarreal
 */

/*
INTERFAZ HECHA
*/


public interface ILLM {
    
    String speak (String mensaje);
    String getId();
    
}
