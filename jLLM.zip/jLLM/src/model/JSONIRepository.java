
package model;


import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.ArrayList;
/**
 *
 * @author LidiaVillarreal
 */


/*
APARENTEMENTE ESTÁ COMPLETO
*/



public class JSONIRepository implements IRepository {

    @Override
    public ArrayList<Conversacion> importarConversaciones() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public boolean exportarConversaciones(ArrayList<Conversacion> conversaciones) {
    
       Path ruta = Paths.get (System.getProperty ("user.home"), "Desktop", "jLLM2", "jLLMJSON.json");
       File f = ruta.toFile ();
       if (!exportarListaDeConversacionesAJSON(conversaciones, f)) {
            System.out.println("Hubo un problema con la exportación");
            return true;
        }else{
            System.out.println("Vea el resultado en:"+f.getAbsolutePath());
            return false;
        } 
    }
    
    public static boolean exportarListaDeConversacionesAJSON(ArrayList<Conversacion> conversaciones, File f) {
        try {
            Gson gson = new Gson();
            String json = gson.toJson(conversaciones);
            Files.write(f.toPath(), json.getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (IOException ex) {
            System.err.println("Error:" + ex.getMessage());
            return false;
        }
    }  

}
