
package model;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import model.Frase;

/**
 *
 * @author LidiaVillarreal
 */


/*
APARENTEMENTE CLASE ACABADA
*/


public class RandomCSVILLM implements ILLM{

    private String id;

    ArrayList <Frase> frases = new ArrayList <> ();
    
    Path ruta = Paths.get(System.getProperty("user.home"), "Desktop", "ILLM2", "datos.txt");
    String delimitador = ",";
    
    
     @Override
    public String speak(String mensaje) {
        @SuppressWarnings("LocalVariableHidesMemberVariable")
        ArrayList <Frase> frases = importarFrases (ruta,delimitador);
        
        //Clasificamos el mensaje por tipo (saludo,despedida,sorpresa...)
        String tipo = clasificarMensaje (mensaje);
        //Seleccionamos solo frases del tipo del mensaje
        ArrayList <Frase> frasesFiltradas = filtrarFrasesPorTipo (frases,tipo);
        // Seleccionar una frase aleatoria de las frases filtradas
        Frase fraseAleatoria = seleccionarFraseAleatoria(frasesFiltradas);
        
        if (fraseAleatoria != null) {
            return fraseAleatoria.getOracion(); // Devolver la oración de la frase seleccionada
        } else {
            return "Lo siento, no tengo frases para ese tipo.";
        }        
    }
    
    public static ArrayList <Frase> importarFrases (Path ruta, String delimitador){
        ArrayList <Frase> frases = new ArrayList <> ();
        try {
            List<String> lineas = Files.readAllLines(ruta);
            for (String linea : lineas) {
                Frase f = Frase.getFraseFromDelimitedString(linea, delimitador);
                if(f != null){
                    frases.add(f);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }         
        return frases;
    }  
    
    
    private Frase seleccionarFraseAleatoria(List<Frase> frasesFiltradas) {
        if (frasesFiltradas.isEmpty()) {
            return null;
        }
        int indiceAleatorio = (int) (Math.random() * frasesFiltradas.size());
        return frasesFiltradas.get(indiceAleatorio);
}
    
    
    private ArrayList <Frase> filtrarFrasesPorTipo (ArrayList <Frase> frases, String tipo){
        ArrayList <Frase> frasesFiltradas = new ArrayList <> ();
        for (Frase f: frases){
            if (f.getTipo ().equalsIgnoreCase(tipo)){
                frasesFiltradas.add (f);
            }
        }
        return frasesFiltradas;
    }

    private String clasificarMensaje(String mensaje) {
        // Lógica de clasificación aquí (por ejemplo, si contiene "hola", clasificar como "saludo")
        if (mensaje.toLowerCase().contains("hola")) {
            return "saludo";
        } else if (mensaje.toLowerCase().contains("adios")) {
            return "despedida";
        } else if (mensaje.toLowerCase().contains("pregunta")) {
            return "pregunta";
        } else if (mensaje.toLowerCase().contains("!")) {
            return "sorpresa";      
        } else {
            // Otra lógica de clasificación si es necesario
            return "refran";
        }
    }

    @Override
    public String getId() {
        return id;
    }
    
    
}
