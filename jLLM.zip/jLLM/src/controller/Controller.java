
package controller;

import java.util.List;
import model.Conversacion;
import model.Model;
import view.AppView;

/**
 *
 * @author Lidia Villarreal
 */
public class Controller {
    
    Model model;
    AppView view;

    public Controller(Model model, AppView view) {
        this.model = model;
        this.view = view;
        view.setController(this);
    }
    
    
    public void initApplication(){
        
        // Carga inicial programa
        if(model.cargarEstadoAplicacion()){
            view.showApplicationStart("Cargado estado anterior con exito");
        }else{
            view.showApplicationStart("No se encontró fichero para carga del programa");
        }
        
        // Menú principal
        view.showMainMenu();
        
        
        // Guardado final del programa
        if(model.guardarEstadoAplicacion()){
            view.showApplicationEnd ("Guardado el estado de la aplicación.\nSaliendo...");
        }else{
            view.showApplicationEnd ("No se pudo guardar el estado de la aplicación.\nSaliendo...");
        }
        
    }
    
    
     public void iniciarConversacion (Conversacion conversacion){
        model.iniciarConversacion (conversacion);
    }
    
    public boolean gestionarConversacion (){
        return model.gestionarConversacion ();
    }
    
    public boolean importarConversaciones (){
        return model.importarConversaciones ();
    }
        
    public boolean exportarConversaciones (){
        return model.exportarConversaciones ();

    }
}
