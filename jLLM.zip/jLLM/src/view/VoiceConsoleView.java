
package view;

/**
 *
 * @author LidiaVillarreal
 */
public class VoiceConsoleView {
    
}
