
package view;

import static com.coti.tools.Esdia.*;

/**
 *
 * @author LidiaVillarreal
 */
public class SimpleConsoleView extends AppView {

    @Override
    public void showApplicationStart(String msgBienvenida) {
        System.out.println ("Bienvenido :)");
    }

    @Override
    public void showMainMenu() {
         int opcion;
        do {
            System.out.println("\n--- MENU jLLM ---");
            System.out.println("1. Iniciar conversacion");
            System.out.println("2. Gestion de conversacion");
            System.out.println("3. Importar conversaciones");
            System.out.println("4. Exportar conversaciones");
            System.out.println("5. Salir");
            opcion = readInt("Ingrese una opcion: ");

            switch (opcion) {
                case 1:
                    iniciarConversacion();
                    break;
                case 2:
                    gestionarConversacion();
                    break;
                case 3:
                    importarConversaciones();
                    break;
                case 4:
                    exportarConversaciones();
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opcion != 5);
    }
   

    @Override
    public void showApplicationEnd(String msgDespedida) {
        System.out.println ("Vuelve cuando quieras !!");
    } 
    
    private void iniciarConversacion (){
        System.out.println ("Iniciando conversacion...");
        String respuesta = readString_ne ("En que le puedo ayudar");
        
        
    }
    
    public void gestionarConversacion (){
        System.out.println ("gestionar conversacion");
    }
    
    public void importarConversaciones (){
        System.out.println ("importar conversacion");
        System.out.println ("Este metodo queda aun por implementar");
        
    }
        
    public void exportarConversaciones (){
        System.out.println ("exportar conversacion");
    }
    
}
