
package MVCjLLM;

import controller.Controller;
import model.MemoryRespository;
import model.Model;
import view.AppView;
import view.VoiceConsoleView;
import view.SimpleConsoleView;
import model.IRepository;
import model.JSONIRepository;
import model.XMLIRepository;
import model.FakeILLM;
import model.ILLM;
import model.RandomCSVILLM;

        



/**
 *
 * @author  Lidia Villarreal
 */
public class MVCjLLM {
    
            
    public static void main (String [] args ){
        
        IRepository repository;
        AppView view;
        ILLM llm;
        
        //Llamada esperada java-jar jjlm.jar respository model vista
        
        if (args.length ==3){
        // Obtener los parámetros
            repository =getRepositoryForOption (args[0]);
            llm=getLLMForOption (args[1]);
            view = getViewForOption (args[2]);
        }else{
            //Por defecto
            view = new SimpleConsoleView ();
            repository = new JSONIRepository ();
            llm = new FakeILLM ();
        }
               
        Model model = new Model (repository, llm);
        Controller c = new Controller (model, view);
        
         c.initApplication();      
        
    }
        
        private static AppView getViewForOption (String argumento){
            switch (argumento) {
                case "consola":
                    return new SimpleConsoleView ();
                case "voz":
                  //  return new VoiceConsoleView ();
                default:
                    return new SimpleConsoleView ();                
            }
            
        }
        
        private static IRepository getRepositoryForOption (String argumento) {
            switch (argumento){
                case "xml":
                    return new XMLIRepository ();
                case "json":
                    return new JSONIRepository ();
                default:
                    return new JSONIRepository ();
            }

        }
        
        
         private static ILLM getLLMForOption (String argumento) {
            return switch (argumento) {
                case "cvs" -> new RandomCSVILLM ();
                //case "smart" -> new Smart ();
                default -> new FakeILLM ();
            };

        }

        
}
        
        
    
   
